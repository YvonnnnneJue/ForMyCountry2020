// pages/send/step1/step1.js
import {get} from '../../../utils/common'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    enterprise: {},
    user: {},
    caShow: '',
    caShowWhat: '',
    remainAmount: 0
  },
  lookCa () {
    wx.showActionSheet({
      itemList: ['查看证书'],
      itemColor:'#00A0E9',
      success(res) {
        wx.navigateTo({
          url:"/pages/myinfo/cainfo/cainfo"
        })
      },
      fail(res) {
        wx.showToast({
          title: err.detail || err.errMsg,
          icon: 'none'
        })
      }
    })
  },
  navigate (event) {
    wx.navigateTo({
      url: "/pages/costcenter/account/account"
    })
  },
  checkCa () {
    get({
      url: '/enterprise/api/ca/status/'
    })
    .then((res)=>{
      let resp = res.data
      let caShow = ''
      let caShowWhat = ''
      if(resp.ca_status == 'ok') {
          caShow = true
          caShowWhat = "正常使用中"
      }else if(resp.ca_status == 'rename') { // 正在改名
          caShow = false
          caShowWhat = '更名中'
      }else if(resp.ca_status == 'renew') { // 正在重新申请
          caShow = false
          caShowWhat = '正在重新申请'
      }else if(resp.ca_status == 'overdue') { // 认证过期
          caShow = false
          caShowWhat = '已过期'
      }else{
          console.log('发生了意外情况')
      }
      this.setData({
        caShow: caShow,
        caShowWhat: caShowWhat
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  getData () {
    get({
      url: '/user/api/my'
    })
    .then((res)=>{
      let data = res.data
      this.setData({
        enterprise: data.enterprise,
        user: data.user
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  getCostcenter () {
    get({
      url: '/account/api/costcenter/home/'
    })
    .then((res)=>{
      this.setData({
        remainAmount: res.data.wq_card.remain_amount
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  logout () {
    get({
      url: '/user/api/logout'
    })
    .then((res)=>{
      wx.reLaunch({
        url: '/pages/login/login'
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getData()
    this.checkCa()
    this.getCostcenter()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})