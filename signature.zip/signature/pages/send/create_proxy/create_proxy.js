// pages/send/create_proxy/create_proxy.js
import {post} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    newProxy: app.globalData.newProxy,
    host: app.globalData.host,
    principal: '',
    date: '请选择有效期'
  },
  principal(e) {
    let value = e.detail.value
    this.setData({
      principal: value
    })
    app.globalData.name = value
  },
  dateChange(e) {
    this.data.newProxy[e.currentTarget.id].date = e.detail.value
    this.setData({
      newProxy: this.data.newProxy
    })
  },
  delProxy (e) {
    delete this.data.newProxy[e.currentTarget.id]
    this.setData({
      newProxy: this.data.newProxy
    })
  },
  upload () {
    let self = this
    let url = this.data.host + '/common/api/v2/upload/authletter/'
    // 选择图片
    wx.chooseImage({
      success (res) {
        const len = res.tempFiles.length - 1
        // 循环调用上传api
        res.tempFilePaths.forEach(function (v, i) {
          const filPath = v
          wx.uploadFile({
            url: url,
            filePath: filPath,
            name: 'file',
            success (res) {
              let data = JSON.parse(res.data)[0]
              let name = data.name
              data['date'] = ''
              let imgData = data
              self.data.newProxy[name] = data
              self.setData({
                newProxy: self.data.newProxy
              })
            },
            fail (err) {
              wx.showToast({
                title: err.detail || err.errMsg,
                icon: 'none'
              })
            }
          })
        })
      }
    })
  },
  checkTime () {
    let data = this.data.newProxy
    let len = data.length
    let timeHasNull = false
    for (let i in data) {
      if (!data[i].date) {
        timeHasNull = true
        break
      }
    }
    return timeHasNull
  },
  setTime () {
    let data = this.data.newProxy
    let len = data.length
    for (let i in data) {
      if (!data[i].date) {
        data[i].date = '2099-12-31'
      }
    }
    this.setData({
      newProxy: data
    })
  },
  save() {
    let self = this
    if (Object.keys(self.data.newProxy).length == 0) {
      wx.navigateBack({delta: 1})
      return
    }
    if (!self.data.principal) {
      wx.showToast({
        title: '请填写受托人姓名',
        icon: 'none'
      })
      return
    }
    if (self.checkTime()) {
      wx.showModal({
        title: '温馨提示',
        content: '到期时间未填写，默认为永久，确认上传？',
        success (res) {
          if (res.confirm) {
            // console.log('用户点击确定')
            self.setTime()
            app.globalData.newProxySaved = self.data.newProxy
            wx.navigateBack({delta: 1})
          } else if (res.cancel) {
            // console.log('用户点击取消')
          }
        }
      })
    } else {
      app.globalData.newProxySaved = self.data.newProxy
      wx.navigateBack({delta: 1})
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      newProxy: app.globalData.newProxy
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    app.globalData.newProxy = {}
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})