// pages/send/choose_proxy/choose_proxy.js
import {get, post} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    documents: null,
    id: 'close',
    name: '',
    newProxySaved: {},
    newProxy: {},
    enterprise_material: '',
    company_id: '',
    downloaded: {}
  },
  // 上传委托书
  upload () {
    let self = this
    let url = this.data.host + '/common/api/v2/upload/authletter/'
    // 选择图片
    wx.chooseImage({
      success (res) {
        const len = res.tempFiles.length - 1
        // 循环调用上传api
        res.tempFilePaths.forEach(function (v, i) {
          const filPath = v
          wx.uploadFile({
            url: url,
            filePath: filPath,
            name: 'file',
            header: {"content-type": "multipart/form-data"},
            success (res) {
              let data = JSON.parse(res.data)[0]
              let name = data.name
              data['date'] = ''
              let imgData = data
              app.globalData.newProxy[name] = data
              if (len == i) {
                wx.navigateTo({
                  url: '/pages/send/create_proxy/create_proxy'
                })
              }
            },
            fail (err) {
              wx.showToast({
                title: err.detail || err.errMsg,
                icon: 'none'
              })
            }
          })
        })
      }
    })
  },
  getData () {
    let self = this
    let enterprise_material = this.data.enterprise_material
    let company_id = this.data.company_id
    get({
      url: '/materialv2/api/compare_enterprise/'+ enterprise_material + '/' + company_id
    })
    .then((res)=>{
      self.setData({
        documents: res.data.enterprise_material.documents
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  clickDocu (e) {
    let id = e.currentTarget.dataset.id
    if (id === 'nodoc') {
      wx.showToast({
        title: '该类目下，没有文件',
        icon: 'none'
      })
    }
    let defaultId = this.data.id
    let setId = id
    if (id === defaultId) {
      setId = 'close'
    }
    this.setData({
      id: setId
    })
  },
  deleteHandle () {
    app.globalData.newProxySaved = {}
    app.globalData.newProxy = {}
    app.globalData.name = ''
    this.setData({
      name: '',
      newProxySaved: '',
      newProxy: ''
    })
  },
  submit () {
    let data = this.data
    let enterprise_material = data.enterprise_material
    let documents = data.documents
    let docLen = documents.length
    let company_id = data.company_id
    let enterprise_files = []
    for (let i = 0; i < docLen; i++) {
      let files = documents[i].files
      for (let j in files) {
        enterprise_files.push(files[j].id)
      }
    }
    // 委托书相关文件
    let newProxySaved = data.newProxySaved
    let files = []
    for (let i in newProxySaved) {
      let res = newProxySaved[i]
      files.push({
        document_name: '法人授权委托书相关文件',
        expire_time: res.date,
        file: res.url,
        name: res.name,
        self_upload: 1,
        transitive: 0
      })
    }
    let datas = {
      enterprise_files : enterprise_files,  // enterprise中的文件uuid 非必需
      files : files,       // 委托书相关文件 非必需
      is_exchange: 'from_material',
      mtl_uuid: enterprise_material,
      receiver_id : company_id,  // 接受方id
      ukey_data: ''
    }
    post({
      url: '/agreement/api/api/enterprise/exchange_v2/',
      data: datas,
      header: {
        "X-CSRFTOKEN": wx.getStorageSync('csrftoken')
      }
    })
    .then((res)=>{
      let msg = res.data.detail
      let uuid = res.data.jump_uuids.exchange_uuid
      // wx.showToast({
      //   title: '当前可发送页数不够用了，请升级您的套餐',
      //   icon: 'none',
      //   duration: 3000
      // })
      // return
      wx.showToast({
        title: msg,
        icon: 'none',
        duration: 3000,
        success () {
          setTimeout(function(){
            wx.navigateTo({
              url: '/pages/status_detail/detail/detail?uuid=' + uuid
            })
          },3000)
        }
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none',
        duration: 3000
      })
    })
  },
  // openPdf (url) {
  //   wx.openDocument({
  //     filePath: url,
  //     success: function (res) {
  //       console.log('打开文档成功')
  //     },
  //     fail(err){
  //       console.log(err)
  //       console.log('打开失败')
  //     }
  //   })
  // },
  // openImg (url) {
  //   wx.previewImage({
  //     current: '', // 当前显示图片的http链接
  //     urls: [url] // 需要预览的图片http链接列表
  //   })
  // },
  // judgeImgOrPdf (url) {
  //   if (url.slice(-4) == '.pdf') {
  //     this.openPdf(url)
  //   } else {
  //     this.openImg(url)
  //   }
  // },
  // downloadPdf: function (e) { // 查看pdf
  //   var self = this
  //   let url = e.currentTarget.dataset.url
  //   console.log(url)
  //   let uuid = e.currentTarget.id
  //   console.log(uuid)
  //   let downloaded = this.data.downloaded
  //   if (downloaded[uuid]) {
  //     self.judgeImgOrPdf(downloaded[uuid])
  //   } else {
  //     var path = url
  //     console.log(url)
  //     if (!url.includes('https://')) {
  //       path = self.data.host + url
  //     }
  //     path = decodeURIComponent(path)
  //     console.log(path)
  //     wx.showLoading({title: '加载中'})
  //     const downloadTask = wx.downloadFile({
  //       url: path,
  //       success: function (res) {
  //         const filePath = res.tempFilePath
  //         // 避免发送方修改文件后，没及时更新
  //         downloaded[uuid] = filePath
  //         self.setData({
  //           downloaded: downloaded
  //         })
  //         wx.hideLoading()
  //         self.judgeImgOrPdf(filePath)
  //       },
  //       fail () {
  //         wx.hideLoading()
  //         wx.showToast({
  //           title: '打开失败',
  //           icon: 'none',
  //           duration: 2000
  //         })
  //       },
  //       complete () {
  //       }
  //     })
  //     downloadTask.onProgressUpdate((res) => {
  //       self.setData({
  //         percent: res.progress
  //       })
  //     })
  //   }
  // },
  downloadPdf: function (e) {
    this.selectComponent('#open-document').downloadPdf(e)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      app: app,
      host: app.globalData.host,
      enterprise_material: options.default_enterprise_material,
      company_id: options.company_id
    })
    this.getData({company_id: options.company_id, enterprise_material: options.default_enterprise_material})
    // this.getData({company_id: 2, enterprise_material: 'edd40e3f-5790-43ee-b9e4-05c21a71fae3'})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      name: app.globalData.name,
      newProxySaved: app.globalData.newProxySaved,
      newProxy: app.globalData.newProxy
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})