// pages/cloudfile/infobank/infobank.js
import {get} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navigationTitle: '',
    fileId: '',
    matId: '',
    showFiles: {},
    addFiles: {},
    getFiles: {},
    host: app.globalData.host,
    downloaded: {},
    noMore: false
  },
  getFilesFun (fileId) {
    get({
      url: '/materialv2/api/enterprise_material_documents/'+ fileId + '/files/'
    })
    .then((res)=>{
      let addFiles = app.globalData.addFiles
      let getFiles = this.initFiles(res.data, fileId)
      let showFiles = app.globalData.showFiles
      if (addFiles[fileId]) {
        addFiles = addFiles[fileId]
      }
      showFiles[fileId] = this.cloneObj(getFiles)
      this.setData({
        addFiles: addFiles,
        showFiles: showFiles[fileId]
      })
      if (Object.keys(addFiles).length == 0 && Object.keys(showFiles[fileId]).length == 0) {
        this.setData({
          noMore: true
        })
      } else {
        this.setData({
          noMore: false
        })
      }
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  initFiles (data, fileId) {
    let obj = {}
    for (let i in data) {
      let id = data[i].id
      obj[id] = data[i]
    }
    app.globalData.showFiles[fileId] = this.cloneObj(obj)
    return obj
  },
  deleteFile (e) {
    let fileId = this.data.fileId
    let id = e.currentTarget.id
    let showFiles = this.data.showFiles
    let addFiles = app.globalData.addFiles
    let deleteFiles = app.globalData.deleteFiles
    if (showFiles[id]) {
      delete showFiles[id]
      deleteFiles.push(id)
    }
    if (!addFiles[fileId]) {
      addFiles[fileId] = {}
    }
    if (addFiles[fileId][id]) {
      delete addFiles[fileId][id]
    }
    app.globalData.showDoc[fileId].total = Object.keys(showFiles).length + Object.keys(addFiles[fileId]).length
    this.setData({
      showFiles: showFiles,
      addFiles: addFiles[fileId]
    })
    app.globalData.showFiles[fileId] = this.cloneObj(showFiles)
  },
  cloneObj (obj) {
    return  JSON.parse(JSON.stringify(obj))
  },
  openPdf (url) {
    wx.openDocument({
      filePath: url,
      success: function (res) {
        console.log('打开文档成功')
      },
      fail(err){
        console.log('打开失败')
      }
    })
  },
  downloadPdf: function (e) { // 查看pdf
    wx.navigateTo({
      url: '/pages/cloudfile/webview/webview?url=' + e.currentTarget.dataset.url
    })
    // this.selectComponent('#open-document').downloadPdf(e)
    // var self = this
    // let url = e.currentTarget.dataset.url
    // let uuid = e.currentTarget.id
    // let downloaded = this.data.downloaded
    // if (downloaded[uuid]) {
    //   self.openPdf(downloaded[uuid])
    // } else {
    //   var path = url
    //   if (!url.includes('https://')) {
    //     path = self.data.host + url
    //   }
    //   path = decodeURIComponent(path)
    //   console.log(path)
    //   wx.showLoading({title: '加载中'})
    //   const downloadTask = wx.downloadFile({
    //     url: path,
    //     success: function (res) {
    //       const filePath = res.tempFilePath
    //       // 避免发送方修改文件后，没及时更新
    //       downloaded[uuid] = filePath
    //       self.setData({
    //         downloaded: downloaded
    //       })
    //       wx.hideLoading()
    //       self.openPdf(filePath)
    //     },
    //     fail () {
    //       wx.hideLoading()
    //       wx.showToast({
    //         title: '打开失败',
    //         icon: 'none',
    //         duration: 2000
    //       })
    //     },
    //     complete () {
    //     }
    //   })
    //   downloadTask.onProgressUpdate((res) => {
    //     self.setData({
    //       percent: res.progress
    //     })
    //   })
    // }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      fileId: options.fileId,
      matId: options.id
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let data = this.data
    let fileId = this.data.fileId
    let globalData = app.globalData
    let addFiles = app.globalData.addFiles
    
    let showFiles = app.globalData.showFiles
    if (!showFiles[fileId]) {
      showFiles[fileId] = {}
      if (this.data.matId != 0) {
        this.getFilesFun(fileId)
      }
    } else {
      this.setData({
        showFiles: showFiles[fileId]
      })
    }
    if (!addFiles[fileId]) {
      addFiles[fileId] = {}
    }
    this.setData({
      addFiles: addFiles[fileId],
      navigationTitle: globalData.showDoc[fileId].name
    })
    wx.setNavigationBarTitle({
      title: this.data.navigationTitle
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})