// pages/cloudfile/company/company.js
import {get, post, _delete, put} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    id: '',
    matId:'',
    enterpriseName: '',
    allData: {},
    documents: [],
    addDoc: {},
    showDoc: {},
    addFiles: app.globalData.addFiles,
    deleteFiles: app.globalData.deleteFiles,
    index: -1
  },
  getDocument () {
    get({
      url: '/materialv2/api/enterprise/detail/' + this.data.id
    })
    .then((res)=>{
      let data = res.data
      this.setData({
        allData: data,
        documents: data.documents
      })
      this.initShowDoc(data.documents, false)
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  initShowDoc (doc, isNew) {
    let showDoc = {}
    for (let i in doc) {
      let id = doc[i].id
      let name = doc[i].name
      let material_type_id = doc[i].material_type_id
      if (name == '营业执照' || name == '生产/经营许可证' || name == 'GSP/GMP证书' || (!material_type_id && !isNew)){
        showDoc[id] = doc[i]
        showDoc[id]['total'] = doc[i].file_count || 0
        showDoc[id]['isNew'] = !material_type_id && !isNew
      }
    }
    app.globalData.showDoc = showDoc
    this.setData({
      showDoc: showDoc
    })
  },
  addDoc (res) {
    let showDoc = this.data.showDoc
    res['material_type_id'] = ''
    res['file_count'] = 0
    res['total'] = 0
    res['isNew'] = true
    showDoc[res.id] = res
    app.globalData.showDoc = showDoc
    this.setData({
      showDoc: showDoc
    })
  },
  delRemoteDiyFile (e) {
    let id = e.currentTarget.id
    
    if (this.data.id ==0) {
      let showDoc = this.data.showDoc
      delete showDoc[id]
      this.setData({
        showDoc: showDoc
      })
    } else {
      _delete({
        url: '/materialv2/api/document/enterprise/',
        header: {"X-CSRFTOKEN": wx.getStorageSync('csrftoken')},
        data: {
          document_id: id
        }
      })
      .then((res)=>{
        let showDoc = this.data.showDoc
        delete showDoc[id]
        this.setData({
          showDoc: showDoc
        })
        app.globalData.showDoc = JSON.parse(JSON.stringify(showDoc))
      })
      .catch((err)=>{
        wx.showToast({
          title: err.data.detail || err.data.errMsg,
          icon: 'none'
        })
      })
    }
  },
  updateCreateNew (value) {
    let id = this.data.id
    post({
      url: '/materialv2/api/document/enterprise',
      header: {"X-CSRFTOKEN": wx.getStorageSync('csrftoken')},
      data: JSON.stringify({
        material_id: id,
        name: value
      })
    })
    .then((res)=>{
      this.addDoc(res.data)
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  createNew (value) {
    let id = this.data.id
    let index = this.data.index
    let showDoc = this.data.showDoc
    showDoc[index] = {
      name: value,
      isNew: true,
      total: 0
    }
    this.setData({
      showDoc: showDoc
    })
  },
  upload (e) {
    let self = this
    let url = this.data.host + '/common/api/v2/upload/product'
    let fileId = e.currentTarget.id
    // 选择图片
    wx.chooseImage({
      success (res) {
        const len = res.tempFiles.length - 1
        // 循环调用上传api
        res.tempFilePaths.forEach(function (v, i) {
          const filPath = v
          wx.uploadFile({
            url: url,
            filePath: filPath,
            name: 'file',
            header: {"content-type": "multipart/form-data"},
            success (res) {
              let data = JSON.parse(res.data)[0]
              let name = data.name
              data['date'] = ''
              let imgData = data
              if (!app.globalData.newUploadFiles[fileId]) {
                app.globalData.newUploadFiles[fileId] = {}
              }
              app.globalData.newUploadFiles[fileId][name] = data
              if (len == i) {
                wx.navigateTo({
                  url: '/pages/cloudfile/create_company/create_company?fileId=' + fileId
                })
              }
            },
            fail (err) {
              wx.showToast({
                title: err.detail || err.errMsg,
                icon: 'none'
              })
            }
          })
        })
      }
    })
  },
  getFiles (e) {
    let count = e.currentTarget.dataset.count
    if(count> 0) {
      wx.navigateTo({
        url: '/pages/cloudfile/infobank/infobank?fileId=' + e.currentTarget.id + '&id='+this.data.id
      })
    } else {
      wx.showToast({
        title: '请先上传文件',
        icon: 'none'
      })
    }
  },
  updateMaterial () {
    let postinfo = this.baseInfoHandle()
    if (postinfo['add'].length == 0 && postinfo['del'].length == 0) {
      wx.showToast({
        title: '请至少上传一个文件！',
        icon: 'none'
      })
      return
    }
    put({
      url: '/materialv2/api/update/enterprise/' + this.data.id,
      header: {"X-CSRFTOKEN": wx.getStorageSync('csrftoken')},
      data: JSON.stringify(postinfo)
    })
    .then((res)=>{
      wx.showToast({
        title: '提交成功',
        success () {
          setTimeout(function () {
            wx.navigateBack({delta: 1})
          },1600)
        }
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  createMaterial () {
    let baseInfo = this.baseInfoHandle()
    if (!baseInfo) {
      wx.showToast({
        title: '请至少上传一个文件！',
        icon: 'none'
      })
      return
    }
    post({
      url: '/materialv2/api/material/enterprise',
      header: {"X-CSRFTOKEN": wx.getStorageSync('csrftoken')},
      data: JSON.stringify(baseInfo)
    })
    .then((res)=>{
      wx.showToast({
        title: '提交成功',
        success () {
          setTimeout(function () {
            wx.navigateBack({delta: 1})
          },1600)
        }
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  save () {
    if (this.data.id == 0) {
      this.createMaterial()
    } else {
      this.updateMaterial()
    }
  },
  baseInfoHandle () {
    let data = this.data
    let allData = data.allData
    let baseInfo = {
      name: allData.name || data.enterpriseName,
      number: allData.number || '',
      owner_enterprise: allData.owner_enterprise || data.enterpriseName,
      urgent: false
    }
    if (this.data.id == 0) {
      return this.arrangePostInof(baseInfo)
    } else {
      return this.updateInfoArrange(baseInfo)
    }
  },
  arrangePostInof (baseInfo) {
    let files = []
    let addFiles = app.globalData.addFiles
    let showDoc = this.data.showDoc
    for (let key in addFiles) {
      let file = addFiles[key]
      let docLen = Object.keys(file).length
      if (docLen) {
        let docs = []
        for (let i in file) {
          let item = file[i]
          docs.push({
            file: item.url,
            name: item.name,
            validity_time: item.date
          })
        }
        files.push({
          name: showDoc[key].name,
          material_type_id: showDoc[key].material_type_id,
          document_files: docs
        })
      }
    }
    if (files.length < 1) {
      return false
    }
    baseInfo['documents'] = files
    return baseInfo
  },
  updateInfoArrange (baseInfo) {
    let add = []
    let addFiles = app.globalData.addFiles
    for (let i in addFiles) {
      let files = addFiles[i]
      for (let j in files) {
        let obj = {
          file: files[j].url,
          material_document_id: i,
          name: files[j].name,
          validity_time: files[j].date
        }
        add.push(obj)
      }
    }
    baseInfo['add'] = add
    baseInfo['del'] = app.globalData.deleteFiles
    return baseInfo
  },
  showDialog() {
    this.dialog.showDialog();
  },
  checkCA () {
    get({
      url: '/enterprise/api/ca/status/',
      header: {"X-CSRFTOKEN": wx.getStorageSync('csrftoken')}
    })
    .then((res)=>{
      let resp = res.data
      if (resp.ca_status == 'ok') {
        caShow = true
      } else if (resp.ca_status == 'rename') { // 正在改名
        caShow = false
        caShowWhat = 'rename'
      } else if (resp.ca_status == 'renew') { // 正在重新申请
        caShow = false
        caShowWhat = 'renew'
      } else if (resp.ca_status == 'overdue') { // 认证过期
        caShow = false
        caShowWhat = 'overdue'
        mainOrsmall = resp.is_main
      } else {
        console.log('发生了意外情况')
      }
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  getMaterialType () {
    get({
      url: '/materialv2/api/material_types?type=1'
    })
    .then((res)=>{
      let data = res.data
      this.setData({
        allData: data,
        documents: data.results,
      })
      this.initShowDoc(data.results, true)
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  _cancelEvent () {
    // console.log('cancel')
  },
  _confirmEvent (e) {
    // console.log('confirm')
    let value = e.detail.value
    if (!value) {
      wx.showToast({
        title: '请输入自定义文件名',
        icon: 'none'
      })
      return
    }
    if (this.data.id == 0) {
      this.createNew(value)
    } else {
      this.updateCreateNew(value)
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id = options.id
    this.setData({
      id: id
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.dialog = this.selectComponent("#dialog"); 
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let id = this.data.id
    let showDoc = app.globalData.showDoc
    if (Object.keys(showDoc).length>0) {
      this.setData({
        showDoc: showDoc
      })
    } else {
      // this.getId()
      if (id != 0) {
        this.getDocument()
      } else {
        this.getMaterialType()
      }
    }
    this.setData({
      enterpriseName: wx.getStorageSync('enterpriseName')
    })
  },
})

// 新建企业资料时，根据id是否为0来判断，缺少为0时的情况，
// 根据(isNew是true或false)及(!material_type_id)来判断，document是否可以删除，都为true才能删除