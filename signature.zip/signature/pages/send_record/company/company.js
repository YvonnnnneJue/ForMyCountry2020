// pages/send_record/company/company.js
import {get} from '../../../utils/common'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    statusList: [
      {title: '全部状态', state: 'all'},
      {title: '已发送', state: 'sent'},
      {title: '已取消', state: 'cancelled'},
      {title: '对方拒绝', state: 'rejected'}
    ],
    sendlist: [],
    next: '',
    state: '',
    search: '',
    noMore: false
  },
  _statusEvent (e) {
    let state = e.detail.state
    this.setData({
      state: state
    })
    this.getData({state, search: this.data.search})

  },
  _searchEvent (res) {
    let search = res.detail.val
    this.setData({
      search: search
    })
    this.getData({search: search})
  },
  getData ({state, next, search}) {
    let self = this
    let url = '/agreement/api/enterprise_exchanges/?role=owner'
    if (next) {
      url = next
    } else {
      if (state && state != 'all') {
        url += '&state=' + state
      }
      if (search) {
        url += '&search=' + search
      } 
    }
    wx.showLoading({
      title: '加载中'
    })
    get({
      url: url
    })
    .then((res)=>{
      let data = res.data
      self.setData({
        sendlist: data.results,
        next: data.next
      })

      let sendlist = data.results
      if (this.data.next){
        sendlist = this.data.sendlist.concat(sendlist)
      }
      if(!data.next){
        this.setData({
          noMore: true
        })
      } else {
        this.setData({
          noMore: false
        })
      }
      this.setData({
        sendlist: sendlist,
        next: res.data.next
      })
      wx.hideLoading()
      wx.stopPullDownRefresh()
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
      wx.hideLoading()
      wx.stopPullDownRefresh()
    })
  },
  navigate (e) {
    let uuid = e.currentTarget.id
    wx.navigateTo({
      url: '/pages/status_detail/detail/detail?uuid=' + uuid
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getData({
      state: 'all',
      noMore: false
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.getData({search: this.data.search})
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (!this.data.noMore) {
      this.getData({search: this.data.search, next: this.data.next})
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})