// pages/status_detail/status_detail.js
import {get, _delete} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fileDet: {},
    fileList: {},
    host: app.globalData.host,
    _key: 'close',
    percent: 0,
    downloaded: {},
    id: '',
    state: '',
    noMore: false,
    reason: ''
  },
  statusEvent (e) {
    let state = e.currentTarget.id
    if (state !== this.data.state) {
      this.setData({
        state: state
      })
    }
    this.initData (this.data.fileDet, state)
  },
  getData (uuid) {
    get({
      url: '/agreement/api/enterprise_exchanges_state/'+uuid
    })
    .then((res)=>{
      if (res.data.data.ret_state == 'receiver_refuse') {
        this.initData(res.data, 'reject')
      } else {
        this.initData(res.data)
      }
      this.setData({
        fileDet: res.data,
        id: res.data.id
      })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  initData (res, _state) {
    let data = res.data
    let state = data.ret_state
    let files = []
    if (state == 'receiver_state_await') { // 待对方处理
      this.setData({
        state: ''
      })
      files = data.files
    } else if (state == 'receiver_refuse') { // 对方拒绝
      this.setData({
        state: _state
      })
      if (_state == 'reject') {
        files = data.reject_table
      } else if (_state == 'padding') {
        files = data.padding_files
      }
    }
    let len = files.length
    let fileList = {}
    if (len == 0) {
      this.setData({
        noMore: true,
        fileList: {}
      })
      return
    } else {
      this.setData({
        noMore: false
      })
    }
    for (let i = 0; i < len; i++) {
      if (files[i].name == 'reason') {
        this.data.reason = files[i].files
        this.setData({
          reason:  files[i].files
        })
        continue
      }
      let name = ''
      if (_state == 'reject') {
        name = files[i].name
      } else {
        name = files[i].document_name
      }
      if (fileList[name] == undefined) {
        fileList[name] = []
      }
      if (_state == 'reject') {
        let list = files[i].files
        let l = list.length
        for (let j = 0; j < l; j++) {
          fileList[name].push(list[j])
        }
      } else {
        fileList[name].push(files[i])
      }
    }
    let _key = 0
    if (_state == 'reject') {
      if (files[0].name == 'reason') {
        _key = 1
      }
      this.setData({
        fileList: fileList,
        _key: files[_key].name
      })
    } else {
      _key = 0
      this.setData({
        fileList: fileList,
        _key: files[0].document_name,
        reason: ''
      })
    }
  },
  open (e) {
    let key = e.currentTarget.id
    if (key == this.data._key) {
      this.setData({
        _key: 'close'
      })
    } else {
      this.setData({
        _key: key
      })
    }
  },
  openPdf (url) {
    wx.openDocument({
      filePath: url,
      success: function (res) {
        console.log('打开文档成功')
      },
      fail(err){
        console.log('打开失败')
      }
    })
  },
  downloadPdf: function (e) { // 查看pdf
    this.selectComponent('#open-document').downloadPdf(e)
    // var self = this
    // let url = e.currentTarget.dataset.url
    // let uuid = e.currentTarget.id
    // let downloaded = this.data.downloaded
    // if (downloaded[uuid]) {
    //   self.openPdf(downloaded[uuid])
    // } else {
    //   var path = url
    //   if (!url.includes('https://')) {
    //     path = self.data.host + url
    //   }
    //   // path = decodeURIComponent(path) 
    //   wx.showLoading({title: '加载中'})
    //   const downloadTask = wx.downloadFile({
    //     url: path,
    //     success: function (res) {
    //       const filePath = res.tempFilePath
    //       // 避免发送方修改文件后，没及时更新
    //       downloaded[uuid] = filePath
    //       self.setData({
    //         downloaded: downloaded
    //       })
    //       wx.hideLoading()
    //       self.openPdf(filePath)
    //     },
    //     fail () {
    //       wx.hideLoading()
    //       wx.showToast({
    //         title: '打开失败',
    //         icon: 'none',
    //         duration: 2000
    //       })
    //     },
    //     complete () {
    //     }
    //   })
    //   downloadTask.onProgressUpdate((res) => {
    //     self.setData({
    //       percent: res.progress
    //     })
    //   })
    // }
  },
  cancel () {
    let id = this.data.id
    let url = '/agreement/api/enterprise_exchanges/' + id + '/quit'
    wx.showModal({
      title: '温馨提示',
      content: '确认取消？取消交换不会返回发送次数。',
      success (res) {
        if (res.confirm) {
          _delete({
            url: url,
            header: {"X-CSRFTOKEN": wx.getStorageSync('csrftoken')},
            data: JSON.stringify({})
          })
          .then((res)=>{
            wx.showToast({
              title: '恭喜您, 取消成功!',
              icon: 'none',
              success () {
                setTimeout(()=>{
                  wx.navigateBack({
                    delta: 1
                  })
                })
              }
            })
          })
          .catch((err)=>{
            wx.showToast({
              title: err.data.detail || err.data.errMsg,
              icon: 'none',
              duration: 3000
            })
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  resend (e) {
    let data = this.data.fileDet
    let type = e.currentTarget.dataset.type
    wx.navigateTo({
      url: '/pages/status_detail/list/list?uuid='+ data.id + '&enterpriseName=' + data.material_name + '&type=' + type
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData(options.uuid)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})