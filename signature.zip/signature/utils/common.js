import config from './config'

function request ({url, data = {}, header={}, method = 'GET'}) {
  let _united_id = wx.getStorageSync('unitedid')
  let Authorization = ''
  let sessionid = wx.getStorageSync('sessionid')
  let csrftoken = wx.getStorageSync('csrftoken')

  if (_united_id) {
    Authorization = 'bearer ' + _united_id 
  }

  let Cookie = 'sessionid=' + sessionid + '; ' + '_united_id=' + _united_id + '; ';
  if (csrftoken) {
    Cookie += 'csrftoken=' + csrftoken + ';'
  }
  header['Cookie'] = Cookie
  header['Authorization'] = Authorization
  if(!url.includes('https://')){

    url = config.host + url
  }
  return new Promise((resolve, reject) => {
    wx.request({
      url,
      data,
      header,
      method,
      success (res) {
        let data = res
        if (200 <= res.statusCode && res.statusCode<300) {
          resolve && resolve(res)
        } else {
          reject && reject(res)
        }
      },
      fail (err) {
        wx.showToast({
          title: err.detail || err.errMsg,
          icon: 'none'
        })
      },
      complete () { }
    })
  })
}


export function get ({url, data, header}) {
  return request({url, method: 'GET', data, header})
}
export function post ({url, data, header}) {
  return request({url, method: 'POST', data, header})
}
export function put ({url, data, header}) {
  return request({url, method: 'PUT', data, header})
}
export function _delete ({url, data, header}) {
  return request({url, method: 'DELETE', data, header})
}
export function patch ({url, data, header}) {
  return request({url, method: 'PATCH', data, header})
}