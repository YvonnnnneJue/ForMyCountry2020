// pages/send/step1/step1.js
import {get} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchKey: '',
    next: '',
    list: [],
    default_enterprise_material: '',
    smallYes: '',
    noMore: false,
    tips: '下拉获取更多'
  },
  // getData (res) {
  //   let searchKey = res.detail.val
  //   this.setData({
  //     searchKey: searchKey
  //   })
  // },
  _searchEvent (res) {
    let searchKey = res.detail.val
    this.setData({
      searchKey: searchKey,
      list: []
    })
    this.getData({search: searchKey, flag: true})
  },
  navigate (e) {
    let uuid = e.currentTarget.dataset.uuid
    let default_enterprise_material = this.data.default_enterprise_material
    wx.navigateTo({
      url: "/pages/send/choose_proxy/choose_proxy?company_id=" + uuid + '&default_enterprise_material=' + default_enterprise_material
    })
  },
  getData ({search, next, flag}) {
    if (!search) {
      search = ''
    }
    let url = '/user/api/user_filter_list/?entrance=enterprise&search=' + search
    if (next) {
      url = next
    }
    get({url: url})
    .then((res) => {
      let data = res.data
      let list = data.results
      let len = this.data.list.length
      // if (this.data.next){
        // list = this.data.list.concat(list)
        this.setData({
          ['list['+len+']']: list,
          next: res.data.next
        })
      // }
      if (flag && data.next) {
        this.getData({search: this.data.search, next: data.next})
      }
      if(!data.next){
        this.setData({
          noMore: true,
          tips: '暂无更多数据'
        })
      } else {
        this.setData({
          noMore: false,
          tips: '下拉获取更多'
        })
      }
      // this.setData({
      //   list: list,
      //   next: res.data.next
      // })
      wx.stopPullDownRefresh()
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
      wx.stopPullDownRefresh()
    })
  },
  getHistory () {
    wx.showLoading({
      title: '加载中',
    })
    get({url: '/agreement/api/e_exc_latest_history/?entrance=enterprise'})
    .then((res) => {
      let data = res.data
      this.setData({
        default_enterprise_material: data.default_enterprise_material
      })
      wx.hideLoading()
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
      wx.hideLoading()
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getHistory()
    this.getData({flag: true})
    this.setData({
      noMore: false
    })
    app.globalData.newProxySaved = {}
    app.globalData.name = ''
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    // wx.showNavigationBarLoading()
    this.getData({search: this.data.searchKey, flag: true})
    // this.selectComponent("#searchInput").getList()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (!this.data.noMore) {
      this.getData({search: this.data.searchKey, next: this.data.next})
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})