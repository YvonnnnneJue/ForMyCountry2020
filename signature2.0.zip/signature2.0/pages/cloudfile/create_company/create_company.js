// pages/send/create_proxy/create_proxy.js
import {post} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    newUploadFiles: {},
    host: '',
    date: '请选择有效期',
    fileId: ''
  },
  dateChange(e) {
    this.data.newUploadFiles[e.currentTarget.id].date = e.detail.value
    this.setData({
      newUploadFiles: this.data.newUploadFiles
    })
  },
  delProxy (e) {
    delete this.data.newUploadFiles[e.currentTarget.id]
    this.setData({
      newUploadFiles: this.data.newUploadFiles
    })
  },
  upload () {
    let self = this
    let url = this.data.host + '/common/api/v2/upload/authletter/'
    // 选择图片
    wx.chooseImage({
      success (res) {
        const len = res.tempFiles.length - 1
        // 循环调用上传api
        res.tempFilePaths.forEach(function (v, i) {
          const filPath = v
          wx.uploadFile({
            url: url,
            filePath: filPath,
            name: 'file',
            success (res) {
              let data = JSON.parse(res.data)[0]
              let name = data.name
              data['date'] = ''
              let imgData = data
              self.data.newUploadFiles[name] = data
              self.setData({
                newUploadFiles: self.data.newUploadFiles
              })
            },
            fail (err) {
              wx.showToast({
                title: err.detail || err.errMsg,
                icon: 'none'
              })
            }
          })
        })
      }
    })
  },
  checkTime () {
    let data = this.data.newUploadFiles
    let len = data.length
    let timeHasNull = false
    for (let i in data) {
      if (!data[i].date) {
        timeHasNull = true
        break
      }
    }
    return timeHasNull
  },
  setTime () {
    let data = this.data.newUploadFiles
    let len = data.length
    for (let i in data) {
      if (!data[i].date) {
        data[i].date = '2099-12-31'
      }
    }
    this.setData({
      newUploadFiles: data
    })
  },
  save() {
    
    if (Object.keys(this.data.newUploadFiles).length == 0) {
      wx.navigateBack({
        delta: 1
      })
      return
    }
    let self = this
    let fileId = self.data.fileId
    let newUploadFiles = self.data.newUploadFiles
    let total = Object.keys(newUploadFiles).length
    let globalData = app.globalData
    let showDoc = globalData.showDoc[fileId]
    let file_count = globalData.showDoc[fileId].file_count
    if (!globalData.addFiles[fileId]){
      globalData.addFiles[fileId] = {}
    }
    if (self.checkTime()) {
      wx.showModal({
        title: '温馨提示',
        content: '到期时间未填写，默认为永久，确认上传？',
        success (res) {
          if (res.confirm) {
            self.setTime()
            
            for (let i in newUploadFiles) {
              globalData.addFiles[fileId][i] = JSON.parse(JSON.stringify(newUploadFiles[i]))
            }
            showDoc.total = total + showDoc.total
            globalData.showDoc[fileId] = showDoc
            globalData.newUploadFiles = {}
            self.setData({
              newUploadFiles: {}
            })
            wx.navigateBack({delta: 1})
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      app.globalData.addFiles[fileId] = JSON.parse(JSON.stringify(newUploadFiles))
      showDoc.total = total + showDoc.total
      globalData.newUploadFiles = {}
      wx.navigateBack({delta: 1})
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      fileId: options.fileId
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let fileId = this.data.fileId
    this.setData({
      name: app.globalData.showDoc[fileId].name,
      host: app.globalData.host,
      newUploadFiles: app.globalData.newUploadFiles[fileId]
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    app.globalData.newUploadFiles = {}
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})