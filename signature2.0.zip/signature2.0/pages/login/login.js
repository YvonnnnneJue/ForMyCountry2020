// pages/login/login.js
import {get, post} from '../../utils/common.js'
import config from '../../utils/config'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    code: '',
    account: '', // 终端 - 正式 - 测试账号
    password: '',
    // account: '01588013@tianzhu.com', // 终端 - 测试环境
    // password: '01588013',
    // account: '13588704841@syzljh.cn', // 终端 - 测试环境
    // password: '13588704841syzljh',
    // account: '15905834665@yzc.com', // 终端 - 测试环境
    // password: '123456',
    account: 'yjd_048689@szy.com', // 终端 - 测试环境
    password: 'lKtMjk',
    // account: '13588704294@syzljh.cn', // 终端 - 测试环境
    // password: '123456',
    // account: '12675194@tianzhu.com', // 商业公司 - 测试环境
    // password: '12675194'
  },
  getAccount (e) {
    this.setData({
      account: e.detail.value
    })
  },
  getPassword (e) {
    this.setData({
      password: e.detail.value
    })
  },
  getType () {
    get({
      url: '/home/api/'
    })
    .then((res)=>{
      let data = res.data
      let type = data.user.type
      wx.hideLoading()
      // wx.navigateTo({
      //   url: '/pages/catalog/catalog'
      // })
      // 后期改回去
      // if (type >= 1) {
      if (type >= 7) {
        let name = data.enterprise.name
        wx.setStorageSync('enterpriseName', name)
        wx.hideLoading()
        wx.redirectTo({
          url: '/pages/catalog/catalog'
        })
      } else {
        this.logout(function(){
          wx.showToast({
            title: '很抱歉，手机版目前只对终端开放',
            icon: 'none'
          })
        })
      }
    })
    .catch((err)=>{
      this.rejectFun(err)
    })
  },
  logout (cb) {
    get({
      url: '/user/api/logout'
    })
    .then((res)=>{
      wx.hideLoading()
      cb && cb()
    })
    .catch((err)=>{
      console.log('退出失败')
    })
  },
  resolveFun (res) {
    let unitedid = this.getWord(res, '_united_id')
    wx.setStorageSync('unitedid', unitedid)
    let sessionid = this.getWord(res, 'sessionid')
    wx.setStorageSync('sessionid', sessionid)
    let csrftoken = this.getWord(res, 'csrftoken')
    wx.setStorageSync('csrftoken', csrftoken)
    // if (res.data.ukey_status !== 'unused') {
    //   this.logout(function(){
    //     wx.showToast({
    //       title: '很抱歉，ukey用户暂时无法使用移动端',
    //       icon: 'none'
    //     })
    //   })
    //   return false
    // }
    this.getType()

  },
  rejectFun (err) {
    wx.showToast({
      title: err.data.detail || err.data.errMsg,
      icon: 'none'
    })
  },
  login () {
    let self = this
    let data = self.data
    let account = data.account
    let password = data.password
    let code = data.code
    
    if(!account) {
      wx.showToast({
        title: '请输入用户名',
        icon: 'none'
      })
      return false
    }
    if(!/^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/.test(account)) {
        wx.showToast({
          title: '请输入合法的用户名',
          icon: 'none'
        })
        return false
    }
    if(!/.{6,}/.test(password)) {
      wx.showToast({
        title: '请输入6-12位密码',
        icon: 'none'
      })
        return false
    }

    let sessionid = wx.getStorageSync('sessionid')
    let Cookie = 'sessionid=' + sessionid + '; ';
    wx.showLoading({
      title: '登录中...',
      mask: true
    })
    wx.request({
      url: config.host + '/user/api/login',
      data: {account, password, code, finger:  Math.random()},
      header: {Cookie},
      method: 'POST',
      success (res) {
        if (200 <= res.statusCode && res.statusCode<300) {
          self.resolveFun(res)
        } else {
          self.rejectFun(res)
        }
      },
      fail (err) {
      },
      complete () {
        wx.hideLoading()
      }
    })
  },
  register () {
    wx.showToast({
      title: '暂未开通注册功能',
      icon: 'none',
      duration: 3000
    })
  },
  getWord (data, key) { // 获取sessionid、_united_id、csrftoken
    if (!data.header['Set-Cookie']) return
    var str = data.header['Set-Cookie']
    let keyIndex = str.indexOf(key)
    if (keyIndex > -1) {
      str = str.slice(keyIndex)
      str = str.slice(str.indexOf('=')+1)
      let index = str.indexOf(';')
      str = str.slice(0, index)
    }
    return str
  },
  getSessionId () {
    get({ // 获取sessionid 的接口
      url: '/system/api/changelog/'
    })
    .then((res) => {
      let sessionid = this.getWord(res, 'sessionid')
      wx.setStorageSync('sessionid', sessionid)
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var self = this
    wx.login({
      success (res) {
        self.data.code = res.code
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.clearStorageSync()
    this.getSessionId()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})