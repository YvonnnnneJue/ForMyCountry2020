// pages/costcenter/account/account.js
import {get} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    costcenter: {},
    percent: 0,
    show: false,
    host: app.globalData.host
  },
  getData () {
    get({
      url: '/account/api/costcenter/home/'
    })
    .then((res)=>{
      this.setData({
        costcenter: res.data
      })
      this.drawArc(res.data.wq_card)
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  drawArc (wqCard) {
    let remain = wqCard.remain_amount
    let total = wqCard.total_amount
    let proportion = remain / total
    // let proportion = 5000 / 10000
    let showProp = 2 * proportion - 2.5
    const ctx = wx.createCanvasContext('canvas')
    // let percent = parseInt(proportion*100)
    let percent = (proportion*100).toFixed(0)
    ctx.setLineWidth(8)
    ctx.arc(60, 60, 50, -.5 * Math.PI, showProp * Math.PI, true)
    ctx.setStrokeStyle('#A5A5A5')
    ctx.stroke()

    ctx.beginPath()
    ctx.arc(60, 60, 50, showProp * Math.PI, -2.5 * Math.PI, true)
    ctx.setStrokeStyle('#22D862')
    ctx.stroke()

    // ctx.beginPath();
	  // ctx.setFontSize(25); // 字体大小 注意不要加引号
	  // ctx.setFillStyle('#22D862');	 // 字体颜色
	  // ctx.setTextAlign("center");	 // 字体位置
	  // ctx.setTextBaseline("middle");	 // 字体对齐方式
	  // ctx.fillText(percent + "%", 60, 60);	 // 文字内容和文字坐标
    ctx.draw()
    this.setData({
      percent: percent
    })
  },
  showImg () {
    this.setData({
      show: true
    })
  },
  hiddenImg () {
    this.setData({
      show: false
    })
  },
  saveImg: function (e) {
    var that = this;
    wx.getImageInfo({ //将获取图片的信息
      src: '../../../images/other/shouyin.jpg',// 需要下载的图片
      success(res){
        var filePath = res.path //得到本地的路径
        wx.saveImageToPhotosAlbum({
          filePath: filePath,
          success(res) {
            wx.showToast({
              title: '保存成功',
              icon: 'success'
            })
          },
          fail (err) {
            wx.showToast({
              title: err.detail || err.errMsg,
              icon: 'none'
            })
          }
        })
      }
    })
  },
  // openImg (e) {
  //   console.log('open')
  //   this.selectComponent('#open-document').downloadPdf(e)
  //   // console.log(this.data.host + '/static/images/shouyin.jpg')
  //   // wx.downloadFile({
  //   //   url: this.data.host + '/static/images/shouyin.jpg',
  //   //   success(res) {
  //   //     const filePath = res.tempFilePath
  //   //     console.log(filePath)
  //   //     wx.openDocument({
  //   //       filePath,
  //   //       success(res) {
  //   //         console.log('打开文档成功')
  //   //       },
  //   //       fail () {
  //   //         console.log('打开失败')
  //   //       }
  //   //     })
  //   //   },
  //   //   fail () {
  //   //     console.log('fail')
  //   //   }
  //   // })
  // },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getData()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})