// pages/catalog/catalog.js
import {get, post} from '../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    smallYes: '', //子账号权限
    csrftoken: wx.getStorageSync('csrftoken'),
    id: '',
    url: ''
  },
  navigate (e) {
    let url = e.currentTarget.dataset.url
    this.setData({
      url: url
    })
    if (url.search('launch=true') < 0) { // 不是 tabBar 中的 ‘首页’
      if (url.search('entrance=enterprise') > 0) { // 点击  发送首营
        this.checkCA()
      } else if (url.search('entrance=cloudfile') > 0) {
        this.getId()
      } else {
        wx.navigateTo({url})
      }
    }
  },
  checkCA () {
    get({
      url: '/enterprise/api/ca/status/',
      header: {"X-CSRFTOKEN": this.data.csrftoken}
    })
    .then((res)=>{
      this.CAStatusFun(res.data.ca_status)
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  getId () {
    get({
      url: '/materialv2/api/enterprise_materials'
    })
    .then((res)=>{
      let data = res.data.results
      let id = 0
      if (data.length > 0) {
        id = data[0].id
      }
      this.setData({
        id: id
      })
      wx.navigateTo({
        url: '/pages/cloudfile/company/company?id=' + id
      })
      // let id = res.data.results[0].id
      // this.setData({
      //   id: id
      // })
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  CAStatusFun (status) {
    let content = ''
    if (status == 'ok') {
      this.checkStatus()
      return
    } else if(status == 'rename') { // 正在改名
      content = '您提交的变更企业名称，还没有通过审核，请等待审核后再操作，如有疑问，请联系客服。'
    } else if (status == 'renew') { // 正在重新申请
      content = '您提交的CA认证续期申请，还没有通过审核，请等待审核后再操作，如有疑问，请联系客服。'
    } else if (status == 'overdue') { // 认证过期
      content = '您提交的CA认证已到期，请续期后操作。'
    } else {
      console.log('发生了意外情况')
    }
    wx.showModal({
      title: '温馨提示',
      content: content,
      showCancel: false,
      confirmText: '知道了'
    })
  },
  checkStatus () { // 判断自己的企业资料是否齐全
    get({
      url: '/agreement/api/e_exc_latest_history/?entrance=enterprise',
      header: {"X-CSRFTOKEN": this.data.csrftoken}
    })
    .then((res)=>{
      wx.navigateTo({
        url: '/pages/send/step1/step1'
      })
    })
    .catch((err)=>{
      if(err.data.detail=='请上传自己的企业资料') {
        wx.showModal({
          title: '温馨提示',
          content: '请确保您的企业资料已完善',
          confirmText: '去完善',
          success (res) {
            if (res.confirm) {
              wx.navigateTo({
                url: '/pages/cloudfile/company/company?id=0'
              })
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.globalData.showDoc = {}
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})