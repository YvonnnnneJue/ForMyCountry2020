// pages/cloudfile/infobank/infobank.js
import {get} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navigationTitle: '',
    index: 0,
    matId: '',
    showFiles: [],
    replaceAdd: {},
    getFiles: {},
    host: app.globalData.host,
    downloaded: {},
    noMore: false
  },
  getFilesFun (fileId) {
    get({
      url: '/materialv2/api/enterprise_material_documents/'+ fileId + '/files/'
    })
    .then((res)=>{
      let replaceAdd = app.globalData.replaceAdd
      let getFiles = this.initFiles(res.data, fileId)
      let showFiles = app.globalData.showFiles
      if (replaceAdd[fileId]) {
        replaceAdd = replaceAdd[fileId]
      }
      showFiles[fileId] = this.cloneObj(getFiles)
      this.setData({
        replaceAdd: replaceAdd,
        showFiles: showFiles[fileId]
      })
      if (Object.keys(replaceAdd).length == 0 && Object.keys(showFiles[fileId]).length == 0) {
        this.setData({
          noMore: true
        })
      } else {
        this.setData({
          noMore: false
        })
      }
    })
    .catch((err)=>{
      wx.showToast({
        title: err.data.detail || err.data.errMsg,
        icon: 'none'
      })
    })
  },
  initFiles (data, fileId) {
    let obj = {}
    for (let i in data) {
      let id = data[i].id
      obj[id] = data[i]
    }
    app.globalData.showFiles[fileId] = this.cloneObj(obj)
    return obj
  },
  deleteFile (e) {
    let index = this.data.index
    let id = e.currentTarget.id
    let showFiles = this.data.showFiles
    let replaceAdd = app.globalData.replaceAdd
    let replaceDelete = app.globalData.replaceDelete
    if (replaceAdd[index]) {
      delete replaceAdd[index][id]
    } else {
      replaceDelete.push(id)
      // app.globalData.replaceDelete.push(id)
    }
    for (let i in showFiles) {
      if (showFiles[i].id === id || showFiles[i].name === id) {
        showFiles.splice(i, 1)
      }
    }
    app.globalData.replaceShowDoc[index].files = showFiles
    this.setData({
      showFiles: showFiles
    })
    if (showFiles.length === 0) {
      wx.navigateBack({delta: 1})
    }
    return 
    if (showFiles[id]) {
      delete showFiles[id]
      replaceDelete.push(id)
    }
    if (!replaceAdd[fileId]) {
      replaceAdd[fileId] = {}
    }
    if (replaceAdd[fileId][id]) {
      delete replaceAdd[fileId][id]
    }
    app.globalData.showDoc[fileId].total = Object.keys(showFiles).length + Object.keys(replaceAdd[fileId]).length
    this.setData({
      showFiles: showFiles,
      replaceAdd: replaceAdd[fileId]
    })
    app.globalData.showFiles[fileId] = this.cloneObj(showFiles)
  },
  cloneObj (obj) {
    return  JSON.parse(JSON.stringify(obj))
  },
  downloadPdf: function (e) {
    this.selectComponent('#open-document').downloadPdf(e)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let index = options.index
    let replaceShowDoc = app.globalData.replaceShowDoc[index]
    let navigationTitle = replaceShowDoc.name
    let showFiles = replaceShowDoc.files
    this.setData({
      index: options.index,
      navigationTitle: navigationTitle,
      showFiles: showFiles
    })
    wx.setNavigationBarTitle({
      title: this.data.navigationTitle
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // let data = this.data
    // let fileId = this.data.fileId
    // let globalData = app.globalData
    // let addFiles = app.globalData.addFiles
    
    // let showFiles = app.globalData.showFiles
    // if (!showFiles[fileId]) {
    //   showFiles[fileId] = {}
    //   if (this.data.matId != 0) {
    //     this.getFilesFun(fileId)
    //   }
    // } else {
    //   this.setData({
    //     showFiles: showFiles[fileId]
    //   })
    // }
    // if (!addFiles[fileId]) {
    //   addFiles[fileId] = {}
    // }
    // this.setData({
    //   addFiles: addFiles[fileId],
    //   navigationTitle: globalData.showDoc[fileId].name
    // })
    // wx.setNavigationBarTitle({
    //   title: this.data.navigationTitle
    // })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})