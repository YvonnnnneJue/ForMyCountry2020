// pages/status_detail/list/list.js
import {get, post} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    dialog: '',
    uuid: '',
    enterpriseName: '',
    csrftoken: '',
    showDoc: [],
    isFilesOwner: false,
    csrftoken: wx.getStorageSync('csrftoken'),
    mobile: '',
    ownerName: ''
  },
  initShowDoc (docs) {
    let showDoc = []
    for (let item of docs) {
      showDoc[item.name] = item
    }
    this.setData({
      showDoc: showDoc
    })
  },
  _showDialog() {
    this.dialog.showDialog();
  },
  //取消事件 
  _cancelEvent () {
    // console.log('cancel')
  },
  _confirmEvent (e) {
    // console.log('confirm')
    let value = e.detail.value
    if (!value) {
      wx.showToast({
        title: '请输入自定义文件名',
        icon: 'none'
      })
      return
    }
    let showDoc = this.data.showDoc
    if (showDoc[value]) {
      wx.showToast({
        title: '您输入的文件名已存在，请重新输入',
        icon: 'none'
      })
      return
    }
    // showDoc[value] = {
    //   files: [],
    //   name: value,
    //   user_defined: true
    // }
    showDoc[showDoc.length] = {
      files: [],
      name: value,
      user_defined: true
    }
    this.setData({
      showDoc: showDoc
    })
    app.globalData.replaceShowDoc = showDoc
    // if (this.data.id == 0) {
    //   this.createNew(value)
    // } else {
    //   this.updateCreateNew(value)
    // }
  },
  _getFiles (msg) {
    let index = msg.detail.index
    wx.navigateTo({
      url: '/pages/status_detail/detail_file/detail_file?index=' + index
    })
  },
  _upload (msg) {
    let self = this
    let url = this.data.host + '/common/api/v2/upload/company/'
    let docName = msg.detail.name
    let index = msg.detail.index
    // let fileId = e.currentTarget.id
    // 选择图片
    wx.chooseImage({
      success (res) {
        const len = res.tempFiles.length - 1
        // 循环调用上传api
        res.tempFilePaths.forEach(function (v, i) {
          const filPath = v
          wx.uploadFile({
            url: url,
            filePath: filPath,
            name: 'file',
            header: {"content-type": "multipart/form-data"},
            success (res) {
              let data = JSON.parse(res.data)[0]
              let name = data.name
              data['expire_time'] = ''
              // if (!app.globalData.replaceUpload[docName]) {
              //   app.globalData.replaceUpload[docName] = {}
              // }
              app.globalData.replaceUpload[name] = data
              if (len == i) {
                wx.navigateTo({
                  url: '/pages/status_detail/replacement/replacement?docName=' + docName + '&index=' + index
                })
              }
            },
            fail (err) {
              wx.showToast({
                title: err.detail || err.errMsg,
                icon: 'none'
              })
            }
          })
        })
      }
    })
  },
  _delRemoteDiyFile () {
    // console.log('delelte remote diy file')
  },
  resend () {
    let gData = app.globalData
    let replaceShowDoc = gData.replaceShowDoc
    let replaceAdd = gData.replaceAdd
    let replaceDelete = gData.replaceDelete
    let self = this.data
    if (self.isFilesOwner || replaceShowDoc.length > 0) {
      if (Object.keys(replaceAdd).length == 0 && replaceDelete.length == 0) {
       wx.showToast({
         title: '您未更改过文件，无需更新资料!',
         icon: 'none'
       })
        return
      }
    } else {
      wx.showToast({
        title: '请联系上游供应企业!',
        icon: 'none'
      })
       return
    }
    let data = {}
    data.del = replaceDelete
    data.add = []
    data.ukey_data = ''
    for (let i in replaceAdd) {
      let files = replaceAdd[i]
      for (let j in files) {
        let file = files[j]
        data.add.push({
          document_name: replaceShowDoc[i].name,
          expire_time: file.expire_time,
          file: file.url,
          name: file.name
        })
      }
    }
    this.requestAgain(data)
    // wx.navigateTo({
    //   url: '/pages/status_detail/detail_file/detail_file'
    // })
  },
  requestAgain (data) {
    post({
      url: '/agreement/api/enterprise_exchanges/'+ this.data.uuid + '/edit/',
      data: data,
      header: {
        "X-CSRFTOKEN": wx.getStorageSync('csrftoken')
      }
    })
    .then(res=>{
      wx.navigateBack({delta: 2})
    })
    .catch(err=>{
      wx.showToast({
        title: err.data.detail,
        icon: 'none'
      })
    })
    // '/agreement/api/enterprise_exchanges/'+ self.id + (this.isReissue ? '/edit/?type=reissue' : '/edit/')
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let uuid = options.uuid
    let enterpriseName = options.enterpriseName
    let type = options.type
    this.setData({
      uuid: uuid,
      enterpriseName: enterpriseName,
    })
    let csrftoken = wx.getStorageSync('csrftoken')
    get({
      url: '/agreement/api/enterprise_exchanges/' + uuid + '/files/',
      "x-csrftoken": csrftoken
    })
    .then(res => {
      let data = res.data
      let mobile = data.mobile
      let ownerName = data.owner_name
      // this.initShowDoc(data.files)
      this.setData({
        isFilesOwner: data.is_files_owner,
        showDoc: data.files,
        mobile: mobile || '',
        ownerName: ownerName || ''
      })
      app.globalData.replaceShowDoc = data.files
    })
    .catch(err => {
      console.log(err)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.dialog = this.selectComponent("#dialog"); 
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      showDoc: app.globalData.replaceShowDoc
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    let gData = app.globalData
    gData.replaceShowDoc = {}
    gData.replaceUpload = {}
    gData.replaceAdd = {}
    gData.replaceDelete = []
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})