// pages/status_detail/replacement/replacement
import {post} from '../../../utils/common'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    docName: '',
    index: 0,
    name: '',
    replaceUpload: {},
    host: '',
    date: '请选择有效期'
  },
  dateChange(e) {
    this.data.replaceUpload[e.currentTarget.id].expire_time = e.detail.value
    this.setData({
      replaceUpload: this.data.replaceUpload
    })
  },
  delProxy (e) {
    delete this.data.replaceUpload[e.currentTarget.id]
    this.setData({
      replaceUpload: this.data.replaceUpload
    })
  },
  upload () {
    let self = this
    let url = this.data.host + '/common/api/v2/upload/company/'
    // 选择图片
    wx.chooseImage({
      success (res) {
        const len = res.tempFiles.length - 1
        // 循环调用上传api
        res.tempFilePaths.forEach(function (v, i) {
          const filPath = v
          wx.uploadFile({
            url: url,
            filePath: filPath,
            name: 'file',
            success (res) {
              let data = JSON.parse(res.data)[0]
              let name = data.name
              data['expire_time'] = ''
              self.data.replaceUpload[name] = data
              self.setData({
                replaceUpload: self.data.replaceUpload
              })
            },
            fail (err) {
              wx.showToast({
                title: err.detail || err.errMsg,
                icon: 'none'
              })
            }
          })
        })
      }
    })
  },
  checkTime () {
    let data = this.data.replaceUpload
    let len = data.length
    let timeHasNull = false
    for (let i in data) {
      if (!data[i].expire_time) {
        timeHasNull = true
        break
      }
    }
    return timeHasNull
  },
  setTime () {
    let data = this.data.replaceUpload
    let len = data.length
    for (let i in data) {
      if (!data[i].expire_time) {
        data[i].expire_time = '2099-12-31'
      }
    }
    this.setData({
      replaceUpload: data
    })
  },
  save() {
    if (Object.keys(this.data.replaceUpload).length == 0) {
      wx.navigateBack({
        delta: 1
      })
      return
    }
    let self = this
    let index = self.data.index
    let replaceUpload = self.data.replaceUpload
    let total = Object.keys(replaceUpload).length
    let globalData = app.globalData
    let replaceShowDoc = globalData.replaceShowDoc[index]
    if (!globalData.replaceAdd[index]){
      globalData.replaceAdd[index] = {}
    }
    if (self.checkTime()) {
      wx.showModal({
        title: '温馨提示',
        content: '到期时间未填写，默认为永久，确认上传？',
        success (res) {
          if (res.confirm) {
            self.setTime()
            for (let i in replaceUpload) {
              let file = replaceUpload[i]
              app.globalData.replaceShowDoc[index].files.push(JSON.parse(JSON.stringify(file)))
              globalData.replaceAdd[index][i] = JSON.parse(JSON.stringify(file))
            }
            wx.navigateBack({delta: 1})
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      for (let i in replaceUpload) {
        let file = replaceUpload[i]
        app.globalData.replaceShowDoc[index].files.push(JSON.parse(JSON.stringify(file)))
        globalData.replaceAdd[index][i] = JSON.parse(JSON.stringify(file))
      }
      wx.navigateBack({delta: 1})
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let docName =  options.docName
    let index =  options.index
    this.setData({
      docName: options.docName,
      index: index,
      host: app.globalData.host,
      replaceUpload: app.globalData.replaceUpload
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    app.globalData.replaceUpload = {}
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})