// 配置地址
const host = 'https://wzh.yxsjob.com'
const config = {
  host
}

export default config
