//app.js
import config from 'utils/config.js'
App({
  onLaunch: function () {
    
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  onShow(){
    if (wx.canIUse('getUpdateManager')) {
      let UpdateManager = wx.getUpdateManager()
      UpdateManager.onCheckForUpdate(function (resp) {
        if (resp.hasUpdate) {
          UpdateManager.onUpdateReady(function () {
            wx.showModal({
              title: '更新提示',
              content: '新版本已经准备好，是否重启应用？',
              success(res) {
                if (res.confirm) {
                  UpdateManager.applyUpdate()
                }
              }
            })
          })
          UpdateManager.onUpdateFailed(function () {
            wx.showModal({
              title: '已经有新版本了',
              content: '新版本已经上线，请您删除当前小程序，重新搜索打开'
            })
          })
        }
      })
    } else {
      wx.showModal({
        title: '温馨提示',
        content: '当前微信版本过低，无法使用该应用，请升级到最新微信版本后重试。'
      })
    }
  },
  onHide(){
    // console.log('app hide')
  },
  onError(){
    // console.log('error')
  },
  globalData: {
    userInfo: null,
    host: config.host,
    newProxy: {},
    newProxySaved: {},
    name: '',
    showDoc: {},
    showFiles: {},
    newUploadFiles: {},
    addFiles: {},
    deleteFiles: [],
    // 补发、重发 start
    replaceShowDoc: {},
    replaceUpload: {},
    replaceAdd: {},
    replaceDelete: []
    // 补发、重发 end
  }
})