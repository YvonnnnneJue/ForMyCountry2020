import config from '../../utils/config'
Component({ 
  options: { 
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  }, 
  /** 
   * 组件的属性列表 
   * 用于组件自定义设置 
  */ 
  properties: {
    placeholder: {type: String, value: ''}
  }, 
  /** 
   * 私有数据,组件的初始数据 
   * 可用于模版渲染 
   */ 
  data: { 
    percent: 0
   }, 
  
  /**
   * 组件的方法列表 
   * 更新属性和数据的方法与更新页面数据的方法类似 
  */ 
  methods: { 
    /** 
    * 公有方法 
    */
   _openDocument () {
     let val = this.data.value
     this.triggerEvent("openDocument")
   },
   openPdf (url, cb) {
    wx.openDocument({
      filePath: url,
      success: function (res) {
        cb && cb()
      },
      fail(err){
        wx.showToast({
          title: err.detail || err.errMsg,
          icon: 'none'
        })
      }
    })
  },
  openImg (url, cb) {
    wx.previewImage({
      current: '', // 当前显示图片的http链接
      urls: [url], // 需要预览的图片http链接列表
      success: function (res) {
        cb && cb()
      },
      fail(err){
        wx.showToast({
          title: err.detail || err.errMsg,
          icon: 'none'
        })
      }
    })
  },
  judgeImgOrPdf (url) {
    let cb = ()=> this.setData({percent: 0})
    if (url.slice(-4) == '.pdf') {
      this.openPdf(url, cb)
    } else {
      this.openImg(url, cb)
    }
  },
  downloadPdf: function (e) { // 查看pdf
    var self = this
    let url = e.currentTarget.dataset.url
    var path = url
    if (!url.includes('https://')) {
      path = config.host + url
    }
    // path = decodeURIComponent(path)
    wx.showLoading({title: '加载中'})
    const downloadTask = wx.downloadFile({
      url: path,
      success: function (res) {
        const filePath = res.tempFilePath
        wx.hideLoading()
        self.judgeImgOrPdf(filePath)
      },
      fail () {
        wx.hideLoading()
        wx.showToast({
          title: '打开失败',
          icon: 'none',
          duration: 2000
        })
      },
      complete () {
        wx.hideLoading()
      }
    })
    downloadTask.onProgressUpdate((res) => {
      self.setData({
        percent: res.progress
      })
    })
  },
  } 
})

// 在父级页面的.wxml文件中添加
//   /**
//    * 生命周期函数--监听页面初次渲染完成
//    */
//   downloadPdf: function (e) {
  //   this.selectComponent('#open-document').downloadPdf(e)
  // },

// 在父级页面的.wxml文件中添加
//   <openDocument id="open-document"></openDocument>   ->  使用组件
//   <view catchtap="downloadPdf" data-url="{{file.file || file.pdf}}"></view>   ->  调用方法